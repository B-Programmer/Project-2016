/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  by.dev.madhead.lzwj.compress.LZW
 *  javafx.application.Platform
 *  javafx.event.ActionEvent
 *  javafx.event.Event
 *  javafx.event.EventHandler
 *  javafx.fxml.FXML
 *  javafx.fxml.Initializable
 *  javafx.scene.Node
 *  javafx.scene.Scene
 *  javafx.scene.control.Button
 *  javafx.scene.control.CheckBox
 *  javafx.scene.control.Label
 *  javafx.scene.control.ProgressBar
 *  javafx.scene.control.TextField
 *  javafx.scene.image.ImageView
 *  javafx.stage.Stage
 *  javafx.stage.Window
 *  javafx.stage.WindowEvent
 *  jfx.messagebox.MessageBox
 *  org.apache.commons.io.FileUtils
 *  org.apache.commons.io.FilenameUtils
 *  pl.mkaczara.bch.code.BCHCode
 *  pl.mkaczara.bch.code.CyclicCode
 *  pl.mkaczara.bch.encoder.BCHEncoder
 */
package controller;

import by.dev.madhead.lzwj.compress.LZW;
import controller.AcquisitionFXMLController;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.stage.Window;
import javafx.stage.WindowEvent;
import jfx.messagebox.MessageBox;
import model.CompressedMedicalImage;
import model.MedicalImage;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import pl.mkaczara.bch.code.BCHCode;
import pl.mkaczara.bch.code.CyclicCode;
import pl.mkaczara.bch.encoder.BCHEncoder;
import util.ViewLoader;

public class CompressionFXMLController
        implements Initializable {

    @FXML
    private CheckBox chkLZW;
    @FXML
    private CheckBox chkBCH;
    @FXML
    private TextField txtCompressionRatio;
    @FXML
    private TextField txtCompressionTime;
    @FXML
    private TextField txtFileSize;
    @FXML
    private TextField txtCompressionRatio1;
    @FXML
    private TextField txtCompressionTime1;
    @FXML
    private TextField txtFileSize1;
    @FXML
    private TextField txtImagePath;
    @FXML
    private TextField txtAcquiredImagePath;
    @FXML
    private ProgressBar prgCompressing;
    @FXML
    private Label lblCompressing;
    @FXML
    private Label lblBCH;
    @FXML
    private Label lblDRatio;
    @FXML
    private Label lblDTime;
    @FXML
    private Label lblDSize;
    @FXML
    private ImageView imgPicture;
    @FXML
    private Button btnNext;
    @FXML
    private Button btnCompress;
    @FXML
    private Button btnBack;
    private ViewLoader viewLoader;
    public static CompressedMedicalImage compressedMedicalImage = new CompressedMedicalImage();

    @FXML
    public void LoadEncryptionView(ActionEvent event) throws IOException {
        final ViewLoader viewLoader = new ViewLoader();
        compressedMedicalImage.setAcquiredImage(AcquisitionFXMLController.medicalImage);
        compressedMedicalImage.setBchUsed(this.chkBCH.isSelected());
        compressedMedicalImage.setLzwUsed(this.chkLZW.isSelected());
        compressedMedicalImage.setCompressionTimeAfterBCH(this.txtCompressionTime1.getText());
        compressedMedicalImage.setCompressionTimeAfterLZW(this.txtCompressionTime.getText());
        compressedMedicalImage.setCompressionRatioAfterLZW(this.txtCompressionRatio.getText());
        compressedMedicalImage.setCompressedImagePath(this.txtImagePath.getText());
        if (!this.txtFileSize1.getText().isEmpty()) {
            compressedMedicalImage.setNewFileSizeAfterBCH(Long.parseLong(this.txtFileSize1.getText().replace("KB", "")));
        }
        if (!this.txtFileSize.getText().isEmpty()) {
            compressedMedicalImage.setNewFileSizeAfterLZW(Long.parseLong(this.txtFileSize.getText().replace("KB", "")));
        }
        if (compressedMedicalImage.getAcquiredImage().isValid()) {
            Stage stage = viewLoader.LoadView("EncryptionFXML", "Medical Image Encryption");
            stage.setOnCloseRequest((EventHandler) new EventHandler<WindowEvent>() {

                public void handle(WindowEvent we) {
                    try {
                        viewLoader.LoadView("FXMLDocument", "Main Screen");
                    } catch (IOException ex) {
                        Logger.getLogger(AcquisitionFXMLController.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            });
            ((Node) event.getSource()).getScene().getWindow().hide();
        }
    }

    @FXML
    public void CompressImage(ActionEvent event) {
        if (this.chkLZW.isSelected()) {
            this.prgCompressing.setVisible(true);
            this.lblCompressing.setVisible(true);
            this.btnBack.setDisable(true);
            this.btnCompress.setDisable(true);
            this.btnNext.setDisable(true);
            try {
                final long startDate = System.currentTimeMillis();
                final String filePath = AcquisitionFXMLController.medicalImage.getFilePath();
                String fileName = AcquisitionFXMLController.medicalImage.getFileName();
                final FileInputStream fileInputStream = new FileInputStream(filePath);
                String folderPath = filePath.replace(fileName, "");
                String extension = FilenameUtils.getExtension((String) filePath);
                String formattedFileName = fileName.replace("." + extension, "");
                final String compressedFilePath = folderPath + formattedFileName + "-compressed" + "." + extension;
                final FileOutputStream fileOutputStream = new FileOutputStream(compressedFilePath);
                final boolean isLZW = this.chkLZW.isSelected();
                final boolean isBCH = this.chkBCH.isSelected();
                File file = new File(filePath);
                if (file.exists()) {
                    Thread thread = new Thread(new Runnable() {

                        @Override
                        public void run() {
                            if (isLZW) {
                                try {
                                    LZW lZW = new LZW();
                                    lZW.compress((InputStream) fileInputStream, (OutputStream) fileOutputStream);
                                    fileInputStream.close();
                                    fileOutputStream.close();
                                    Platform.runLater(new Runnable() {
                                        public void run() {
                                            compressImage1(compressedFilePath, startDate);
                                        }
                                    });
                                } catch (IOException ex) {
                                    Logger.getLogger(CompressionFXMLController.class.getName()).log(Level.SEVERE, null, ex);
                                }
                            }
                            if (isBCH) {
                                final long startDate2 = System.currentTimeMillis();
                                try {
                                    long startDate3 = System.currentTimeMillis();
                                    Platform.runLater(new Runnable() {
                                        public void run() {
                                            prgCompressing.setVisible(true);
                                            lblCompressing.setVisible(true);
                                        }
                                    });
                                    byte[] bytes = isLZW ? FileUtils.readFileToByteArray((File) new File(compressedFilePath)) : FileUtils.readFileToByteArray((File) new File(filePath));
                                    BCHEncoder encoder = new BCHEncoder((CyclicCode) BCHCode.BCH_1023_873);
                                    byte[] encoded = encoder.encode(bytes);
                                    FileUtils.writeByteArrayToFile((File) new File(compressedFilePath), (byte[]) encoded);
                                    Platform.runLater(new Runnable() {
                                        public void run() {

                                            compressImage2(compressedFilePath, startDate2);
                                        }
                                    });
                                } catch (IOException ex) {
                                    Logger.getLogger(CompressionFXMLController.class.getName()).log(Level.SEVERE, null, ex);
                                }
                            }

                        }

                        private void compressImage2(String string, long l) {
                            long fileSize = FileUtils.sizeOf((File) new File(string)) / 1024;
                            txtFileSize1.setText(String.valueOf(fileSize) + "KB");
                            long endDate = System.currentTimeMillis();
                            long difference = endDate - l;
                            txtCompressionTime1.setText("" + difference / 1000 + " S");
                            String lZWCompressionRatio = "" + (100.0f - (float) (FileUtils.sizeOf((File) new File(string)) / 1024) * 100.0f / (float) AcquisitionFXMLController.medicalImage.getFileSize()) + "%";
                            txtCompressionRatio1.setText(lZWCompressionRatio);
                            prgCompressing.setVisible(false);
                            lblCompressing.setVisible(false);
                            txtImagePath.setText(string);
                            imgPicture.setVisible(true);
                        }

                        private void compressImage1(String string, long l) {
                            long fileSize = FileUtils.sizeOf(new File(string)) / 1024;
                            txtFileSize.setText(String.valueOf(fileSize) + "KB");
                            txtImagePath.setText(string);
                            long endDate = System.currentTimeMillis();
                            long difference = endDate - l;
                            txtCompressionTime.setText("" + (difference / 1000 + 1) + " Second(s)");
                            String lZWCompressionRatio = "" + (100.0f - (float) (FileUtils.sizeOf((File) new File(string)) / 1024) * 100.0f / (float) AcquisitionFXMLController.medicalImage.getFileSize()) + "%";
                            txtCompressionRatio.setText(lZWCompressionRatio.replace("-", ""));
                            prgCompressing.setVisible(false);
                            lblCompressing.setVisible(false);
                            imgPicture.setVisible(true);
                            btnBack.setDisable(false);
                            btnCompress.setDisable(false);
                            btnNext.setDisable(false);
                            Stage stage = new Stage();
                            MessageBox.show((Window) stage, (String) "Image Compressed Successfully", (String) "INFO", (int) 67305472);
                        }
                    });
                    thread.start();
                }
            } catch (IOException e) {
                prgCompressing.setVisible(false);
                lblCompressing.setVisible(false);
            }
        }
        else
        {
            Stage stage = new Stage();
            MessageBox.show((Window)stage, "Please select compression algorithm to use", "WARNING !!!", (int)67305472);
        }
    }

    @FXML
    public void LoadPreviousView(ActionEvent event) throws IOException {
        this.viewLoader = new ViewLoader();
        this.viewLoader.LoadView("AcquisitionFXML", "Medical Image Acquisition");
        ((Node) event.getSource()).getScene().getWindow().hide();
    }

    public void initialize(URL url, ResourceBundle rb) {
        this.prgCompressing.setVisible(false);
        this.lblCompressing.setVisible(false);
        this.imgPicture.setVisible(false);
        this.chkBCH.setVisible(false);
        this.txtCompressionRatio1.setVisible(false);
        this.txtCompressionTime1.setVisible(false);
        this.txtFileSize1.setVisible(false);
        this.lblBCH.setVisible(false);
        this.lblDRatio.setVisible(false);
        this.lblDTime.setVisible(false);
        this.lblDSize.setVisible(false);
        String path = AcquisitionFXMLController.medicalImage.getFilePath();
        this.txtAcquiredImagePath.setText(path);
        if (compressedMedicalImage.getCompressedImagePath() != null) {
            this.txtImagePath.setText(compressedMedicalImage.getCompressedImagePath());
            this.txtFileSize.setText(String.valueOf(compressedMedicalImage.getNewFileSizeAfterLZW()) + "KB");
            this.txtCompressionTime.setText(compressedMedicalImage.getCompressionTimeAfterLZW());
            this.txtCompressionRatio.setText(compressedMedicalImage.getCompressionRatioAfterLZW());
            this.imgPicture.setVisible(true);
        }
    }

}
