/*
 * Decompiled with CFR 0_110.
 */
package util;

import java.io.File;
import java.io.FileFilter;

public class MedicalImageFilter
implements FileFilter {
    @Override
    public boolean accept(File file) {
        return false;
    }
}

