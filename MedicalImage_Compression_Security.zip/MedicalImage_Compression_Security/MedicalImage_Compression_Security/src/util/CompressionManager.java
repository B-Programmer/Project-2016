/*
 * Decompiled with CFR 0_110.
 */
package util;

public class CompressionManager {
}

