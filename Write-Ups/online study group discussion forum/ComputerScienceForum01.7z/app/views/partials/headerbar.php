<div class="headerbar" role="banner">
    <div class="inner">

        <div id="site-description">
            <h1>Discussion Forum</h1>
            <p>For Computer Science Students</p>
            <p class="skiplink"><a href="#start_here">Skip to content</a></p>
        </div>

    </div>
</div>