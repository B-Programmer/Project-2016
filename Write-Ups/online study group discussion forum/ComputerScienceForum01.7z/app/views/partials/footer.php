
<div id="page-footer" role="contentinfo">
    <div class="navbar" role="navigation">
        <div class="inner">

            <ul id="nav-footer" class="linklist bulletin" role="menubar">
                <li class="small-icon icon-home breadcrumbs">
                    <span class="crumb"><a href="index.php" data-navbar-reference="index">Board index</a></span>
                </li>
            </ul>
        </div>
    </div>

    <div class="copyright">
        Template From <a href="#">phpBB</a>&reg; Designed By &copy; <a>Remtech Global Conecpts</a>
    </div>
</div>