<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <title>Discussion Forum</title>

    <link rel="alternate" type="application/atom+xml" title="Feed - Computer Science Forum" href="feed.php">
    <link href="public/styles/prosilver/theme/stylesheet54d3.css?assets_version=1" rel="stylesheet">
    <link href="public/styles/prosilver/theme/en/stylesheet54d3.css?assets_version=1" rel="stylesheet">
    <link href="public/styles/prosilver/theme/responsive54d3.css?assets_version=1" rel="stylesheet" media="all and (max-width: 700px)">

    <link href="public/styles/prosilver/theme/plupload.css?assets_version=1" rel="stylesheet">




    <!--[if lte IE 9]>
            <link href="./public/styles/prosilver/theme/tweaks.css?assets_version=1" rel="stylesheet">
    <![endif]-->





</head>