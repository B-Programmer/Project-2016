<!--<div class="footer">
    <div class="footer-inner">
        <div class="footer-content">
            <span class="bigger-120">
                <span class="blue bolder">Computer Science</span>
                Forum &copy; <?php //echo date('Y') ?>
            </span>

        </div>
    </div>
</div>-->