<ul class="nav nav-list">
    <li class="">
        <a href="index.html">
            <i class="menu-icon fa fa-tachometer"></i>
            <span class="menu-text"> Dashboard </span>
        </a>

        <b class="arrow"></b>
    </li>

    <li class="">
        <a href="?controller=forum&action=index">
            <i class="menu-icon fa fa-desktop"></i>
            <span class="menu-text">
                Forum
            </span>
        </a>

    </li>

<!--    <li class="">
        <a href="?controller=topic&action=index">
            <i class="menu-icon fa fa-desktop"></i>
            <span class="menu-text">
                Topics
            </span>
        </a>

    </li>

    <li class="">
        <a href="?controller=post&action=index">
            <i class="menu-icon fa fa-list"></i>
            <span class="menu-text"> Posts </span>
        </a>
    </li>-->

</ul><!-- /.nav-list -->
